#!/bin/bash
ssh -i "/home/gokulraj/program_files/Gokul/madeInTrees/keys/mitApp.pem" ubuntu@13.127.123.56


#ssh-keygen -R 13.127.123.56
#sudo chmod 600 ec2-key-pair.pem
